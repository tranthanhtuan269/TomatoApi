url = document.location.toString();
if (url.match(/phpcrawl\.cuab\.de/))
{
  document.write("<div style=\"border: 1px solid black; width: 728; margin-right:  auto; margin-left: auto;\">\r\n"+
                  "<script type=\"text/javascript\"><!--\r\n"+
                  "google_ad_client = \"ca-pub-4351312586851155\";\r\n"+
                  "/* phpcrawl leaderboard */\r\n"+
                  "google_ad_slot = \"2902057176\";\r\n"+
                  "google_ad_width = 728;\r\n"+
                  "google_ad_height = 90;\r\n"+
                  "//-->\r\n"+
                  "</script>\r\n"+
                  "<script type=\"text/javascript\"\r\n"+
                  "src=\"http://pagead2.googlesyndication.com/pagead/show_ads.js\">\r\n"+
                  "</script>\r\n"+
                 "</div>\r\n<br />");
}