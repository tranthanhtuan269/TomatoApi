<?php
	include("simple_html_dom.php");

	$url = 'https://www.amazon.com/NURSAL-Rechargeable-Stimulator-Management-Rehabilitation/dp/B06XXHLS75/';
	
	$context = stream_context_create(array('http' => array('header' => 'User-Agent: Mozilla compatible')));
  	$response = file_get_contents($url, false, $context);
  	$html = str_get_html($response);
  	
	var_dump($html);die;
?>